package Zhis.hide.clear.button;

import android.view.View;
import android.view.ViewGroup;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG            = "HideClearButton";
    private static final String TARGET_PACKAGE = "com.miui.home";
    private static final String TARGET_CLASS   = "com.miui.home.recents.views.RecentsContainer";
    private static final String TARGET_METHOD  = "setupVisible";
    private static final String FIELD_NAME     = "mMemoryAndClearContainer";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!TARGET_PACKAGE.equals(lpparam.packageName)) return;

        XposedBridge.log(TAG + " → loaded in " + lpparam.packageName);

        try {
            XposedHelpers.findAndHookMethod(
                TARGET_CLASS,
                lpparam.classLoader,
                TARGET_METHOD,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        try {
                            Object container = XposedHelpers.getObjectField(
                                param.thisObject, FIELD_NAME
                            );
                            if (container instanceof ViewGroup) {
                                ((ViewGroup) container).setVisibility(View.GONE);
                            }
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + " → hide failed: " + t.getMessage());
                        }
                    }
                }
            );
        } catch (Throwable t) {
            // 目标类/方法不存在时仅记录，不影响系统桌面启动
            XposedBridge.log(TAG + " → hook failed: " + t.getMessage());
        }
    }
}